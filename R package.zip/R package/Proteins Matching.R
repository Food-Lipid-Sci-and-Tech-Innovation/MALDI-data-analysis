
library(readxl)
library(dplyr)
library(writexl)


database_df <- read_excel("C:/Users/SunFe/Desktop/protein database.xlsxx")
export_df <- read_excel("C:/Users/SunFe/Desktop/protein m/z.xlsx")


database_data <- as.matrix(database_df[, 1:145]) 
export_data <- export_df$export 


find_matching_values <- function(value, target_matrix) {
 
  matching_values <- sapply(seq_len(ncol(target_matrix)), function(col_index) {
    col_values <- target_matrix[, col_index]
    matches <- col_values[abs(col_values - value) < 0.05]
    return(matches)
  })
 
  matched_values <- unique(unlist(matching_values))
  return(if (length(matched_values) > 0) paste(matched_values, collapse = ";") else NA)
}


export_df$match results <- sapply(export_data, function(export_value) {
  find_matching_values(export_value, database_data)
})


write_xlsx(export_df, "protein matching.xlsx")




library(readxl)
library(dplyr)
library(writexl)


database_df <- read_excel("C:/Users/SunFe/Desktop/protein database.xlsx")
export_df <- read_excel("C:/Users/SunFe/Desktop/protein matching.xlsx")


database_data <- database_df %>%
  select(1:145) %>%
  as.matrix()
protein_names <- database_df$protein_name


export_data <- export_df %>%
  select(2:4) %>%
  as.matrix()


find_matching_protein_names <- function(values, target_matrix, protein_names) {

  matching_protein_names <- list()
 
  for (i in seq_len(nrow(values))) {
    row_values <- values[i, ]
    
  
    row_values <- row_values[!is.na(row_values) & row_values != ""]
    
    if (length(row_values) == 0) {
      matching_protein_names[[i]] <- NA
      next
    }
    
    matches <- NULL
    
   
    for (j in seq_len(ncol(target_matrix))) {
      target_column <- target_matrix[, j]
     
      matched_rows <- which(row_values %in% target_column)
      if (length(matched_rows) > 0) {
        matches <- unique(c(matches, matched_rows))
      }
    }
    
   
    if (length(matches) > 0) {
      matching_protein_names[[i]] <- unique(protein_names[matches])
    } else {
      matching_protein_names[[i]] <- NA
    }
  }
  
 
  return(matching_protein_names)
}


export_df$match results <- sapply(1:nrow(export_data), function(i) {
  match_result <- find_matching_protein_names(export_data[i, , drop = FALSE], database_data, protein_names)
  if (length(match_result[[1]]) > 0) {
    paste(match_result[[1]], collapse = ";")
  } else {
    NA
  }
})


write_xlsx(export_df, "protein matching1.xlsx")




library(readxl)
library(dplyr)
library(writexl)


df <- read_excel("C:/Users/SunFe/Desktop/protein matching1.xlsx")


df_cleaned <- df %>% filter(!is.na(df[[2]])) 


print(df_cleaned)


write_xlsx(df_cleaned, "protein matching2.xlsx")



library(readxl)
library(dplyr)
library(writexl)


result_df <- read_excel("C:/Users/SunFe/Desktop/protein matching2.xlsx")


result_df$number of proteins <- sapply(result_df$match results, function(x) {
  if (is.na(x) || x == "") {
    return(0)
  } else {
    
    return(length(unlist(strsplit(x, ";"))) )
  }
})


print(result_df)


write_xlsx(result_df, "protein matching3.xlsx")
