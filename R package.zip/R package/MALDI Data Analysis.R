
if (!requireNamespace("MALDIquant", quietly = TRUE)) {
  install.packages("MALDIquant")
}
if (!requireNamespace("MALDIquantForeign", quietly = TRUE)) {
  install.packages("MALDIquantForeign")
}
library(MALDIquant)
library(MALDIquantForeign)


num_sample <- 4
num_rep <- 4


spectra <- list()


for (i in 1:4) {
  for (j in 1:num_rep) {

    filename <- paste0("C:/Users/SunFe/Desktop/XXX/", i, "-", j, ".mzXML")
    
    spectra[length(spectra)+1] <- import(filename)
  }
}



table(sapply(spectra, length))
any(sapply(spectra, isEmpty))
all(sapply(spectra, isRegular))

spectra <- trim(spectra)
spectra <- transformIntensity(spectra, method="sqrt")
spectra <- smoothIntensity(spectra, method="SavitzkyGolay", halfWindowSize=200)

for(i in 1:length(spectra)){
 baseline <- estimateBaseline(spectra[[i]], method="SNIP", iterations=150)
}

spectra <- removeBaseline(spectra, method="SNIP", iterations=150)
spectra <- calibrateIntensity(spectra, method="TIC")
spectra <- alignSpectra(spectra)
length(spectra)

groups <- factor(c("a","a","a","a","b","b","b","b","c","c","c","c","d","d","d","d"), levels=c("a","b","c","d"))
avgSpectra <- averageMassSpectra(spectra, labels=groups, method="mean")

length(avgSpectra)



#noise <- estimateNoise(avgSpectra[[1]]) 
#plot(avgSpectra[[1]], xlim=c(2000,20000), ylim=c(0, 0.015))
#lines(noise, col="red")
#lines(noise[, 1], 2*noise[, 2], col="blue")

peaks <- detectPeaks(avgSpectra, SNR=6, halfWindowSize=20)

peaks <- binPeaks(peaks)

groups <- factor(c("a","b","c","d"), levels=c("a","b","c","d"))

peaks <- filterPeaks(peaks, minFrequency=c(0.5, 0.5), labels=groups, mergeWhitelists=TRUE)

featureMatrix <- intensityMatrix(peaks, avgSpectra)


write.csv(featureMatrix, "C:/Users/SunFe/Desktop/111.csv ", row.names= FALSE )
