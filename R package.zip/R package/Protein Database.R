
install.packages("Biostrings")
install.packages("writexl")

library(Biostrings)
library(writexl)

    filename <- paste0("C:/2/",".fasta")

fasta_file <- "C:/2.fasta"
fasta_sequences <- readAAStringSet(fasta_file)


data <- data.frame(
  Gene = names(fasta_sequences),
  Protein = names(fasta_sequences),
  AA = as.character(fasta_sequences),
  stringsAsFactors = FALSE
)


truncate_text <- function(text, max_length = 32767) {
  if (nchar(text) > max_length) {
    return(substr(text, 1, max_length))
  } else {
    return(text)
  }
}


data$AA <- sapply(data$AA, truncate_text)


write_xlsx(data, "C:/Users/SunFe/Desktop/111.csv")

library(readxl)
library(writexl)
library(stringr)

file_path <- "path_to_your_excel_file.xlsx"
data <- read_excel(file_path)


extract_gn <- function(gene_text) {

  matches <- str_match(gene_text, "GN=([^;]*)(?=;|PE=)")
  if (!is.na(matches[1, 2])) {
    return(matches[1, 2])
  } else {
    return(NA)
  }
}


data$GN <- sapply(data$Gene, extract_gn)


write_xlsx(data, path = "C:/Users/SunFe/Desktop/111.csv")

library(readxl)
library(dplyr)
library(stringr)
library(writexl)


file_path <- "C:/Users/SunFe/Desktop/111.csv"
data <- read_excel(file_path)


extract_protein <- function(gene_text) {

  matches <- str_match(gene_text, "_HUMAN([^;]*)(?=;|OS=)")
  if (!is.na(matches[1, 2])) {
    return(matches[1, 2])
  } else {
    return(NA)
  }
}

data$Protein <- sapply(data$Gene, extract_protein)

write_xlsx(data, path = "C:/Users/SunFe/Desktop/111.csv")







library(readxl)    
library(dplyr)     
library(openxlsx)  


vesiclepedia_path <- "C:/Users/SunFe/Desktop/Vesiclepedia.xlsx"
gene_data <- read_excel(vesiclepedia_path)

other_file_path <- "C:/Users/SunFe/Desktop/111.csv"
gn_data <- read_excel(other_file_path)


matching_genes <- gene_data$Gene
gn_data$Highlight <- ifelse(gn_data$GN %in% matching_genes, "YES", "NO")


write.xlsx(gn_data, file = "highlighted_results.xlsx")


wb <- loadWorkbook("highlighted_results.xlsx")


sheet <- 1


num_rows <- nrow(gn_data)


yellow_fill <- createStyle(fgFill = "#FFFF00")


for (i in 1:num_rows) {
  if (gn_data$Highlight[i] == "YES") {
    addStyle(wb, sheet = sheet, style = yellow_fill, rows = i + 1, cols = 1:ncol(gn_data), gridExpand = TRUE)
  }
}


saveWorkbook(wb, "highlighted_results.xlsx", overwrite = TRUE)





library(openxlsx) 


file_path <- "C:/Users/SunFe/Desktop/highlighted_results.xlsx"
original_data <- read.xlsx(file_path, sheet = 1)


filtered_data <- original_data[original_data$Highlight == "YES", ]


write.xlsx(filtered_data, file = "filtered_results.xlsx", rowNames = FALSE)




library(openxlsx) 


calculate_molecular_weight <- function(sequence) {

  amino_acid_weights <- c(
    A = 89.0935, R = 174.2017, N = 132.1184, D = 133.1032, C = 121.159, 
    E = 147.1299, Q = 146.1451, G = 75.0669, H = 155.1552, I = 131.1736, 
    L = 131.1736, K = 146.1882, M = 149.2124, F = 165.19, P = 115.131, 
    S = 105.093, T = 119.1197, W = 204.2262, Y = 181.1894, V = 117.1469
  )
  

  weight <- sum(amino_acid_weights[strsplit(sequence, NULL)[[1]]])
  return(weight)
}


file_path <- "C:/Users/SunFe/Desktop/filtered_results.xlsx"
data <- read.xlsx(file_path, sheet = 1)


data$molecular_weight <- sapply(data$AA, calculate_molecular_weight)


write.xlsx(data, file = "C:/Users/SunFe/Desktop/filtered_results.xlsx", rowNames = FALSE)




install.packages("readxl")
install.packages("dplyr")
install.packages("openxlsx")
library(readxl)
library(dplyr)
library(openxlsx)

data <- read_excel("C:/Users/SunFe/Desktop/filtered_results.xlsx")


cleaned_data <- data %>% filter(!is.na(`molecular_weight`) & `molecular_weight` != "")


write.xlsx(cleaned_data, "filtered_results_cleaned.xlsx", row.names = FALSE)




install.packages("readxl")
install.packages("dplyr")
install.packages("openxlsx")
library(readxl)
library(dplyr)
library(openxlsx)

filtered_results_cleaned <- read_excel("C:/Users/SunFe/Desktop/filtered_results_cleaned.xlsx")


filtered_results_cleaned <- filtered_results_cleaned %>%
  mutate(
    Max charge = floor(`molecular_weight` / 20000) + 1,  
    Min charge = floor(`molecular_weight` / 2000)        
  )


write.xlsx(filtered_results_cleaned, "Calculate charge.xlsx", row.names = FALSE)








install.packages("readxl")
install.packages("dplyr")
install.packages("purrr")
install.packages("openxlsx")


library(readxl)
library(dplyr)
library(purrr)
library(openxlsx)


data <- read_excel("C:/Users/SunFe/Desktop/Calculate charge.xlsx")


print(head(data))


data_processed <- data %>%
  rowwise() %>%
  mutate(
    
   charge = list(seq(from = Min charge, to = Max charge)),
    
    
    result = list(molecular_weight + 1.0078 * amino acids)
  ) %>%

  mutate(
    
    num_results = length(amino acids[[1]]),
   
    result_columns = map(1:num_results, ~ .x + 1) %>%
      map(~ setNames(as.data.frame(matrix(NA, nrow = n(), ncol = num_results)), 
                     paste0("Caliculate results_", seq_len(num_results)))),
    
    result_columns = map2(result_columns, Caliculate results, ~ `rownames<-`(.x, as.character(1:nrow(.x))) %>%
                           as.data.frame() %>%
                           mutate(across(everything(), ~ .[seq_len(nrow(.x))])) %>%
                           `rownames<-`(NULL))
  ) %>%
  ungroup() %>%
 
  select(-amino acids, -Caliculate results, -num_results)

print(head(data_processed))


write.xlsx(data_processed, "Caliculate results_processed.xlsx", row.names = FALSE)


cat("Conpleted， 'Caliculate results_processed.xlsx'\n")



library(readxl)
library(dplyr)
library(openxlsx)


data <- read_excel("Caliculate results_processed.xlsx")


print(head(data))


data_processed <- data %>%
  rowwise() %>%
  mutate(
       m_z = list(Caliculate results / median_list[[1]])
  ) %>%
  ungroup() %>%

  mutate(
    num_results = length(m_z[[1]]),

    m_z_columns = map(1:num_results, ~ paste0("m/z_", .x)),
  
    m_z_expanded = map2(as.data.frame(matrix(NA, nrow = n(), ncol = num_results)), m_z, ~ {
      .x[] <- unlist(.y)
      colnames(.x) <- .m_z_columns
      .x
    })
  ) %>%
  ungroup() %>%

  select(-median_list, -m_z, -num_results, -m_z_columns, -m_z_expanded)


print(head(data_processed))


write.xlsx(data_processed, "Calculate results_final.xlsx", row.names = FALSE)


cat("Conpleted， 'Calculate results_final.xlsx'\n")
