
install.packages("readxl")
install.packages("CHNOSZ")
install.packages("writexl")

library(readxl)
library(CHNOSZ)
library(writexl)


    filename <- paste0("C:/1/",  ".xlsx")


data <- readxl::read_excel("C:/1.xlsx", sheet = "12")


calculate_molecular_weight <- function(formula) {
  molecular_weight <- CHNOSZ::mass(formula)
  return(molecular_weight)
}


data$Molecular_Weight <- sapply(data[[2]], calculate_molecular_weight)


writexl::write_xlsx(data, "C:/Users/SunFe/Desktop/2.csv ")




install.packages("readxl")
install.packages("writexl")
library(readxl)
library(writexl)
df <- read_excel("C:/Users/SunFe/Desktop/2.xlsx")


df$mz <- df$Molecular_Weight + 1.0078


write_xlsx(df, "3.xlsx")
